import java.util.*;
class Assignment5 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
		System.out.println("Enter a string: ");
		String str = in.nextLine();
		int l1=str.length();
		System.out.println("Enter a character: ");
		char ch=in.nextLine().charAt(0);
		String temp = String.valueOf(ch);
		String str2=str.replaceAll(temp,"");
		int l2=str2.length();
        int charcount = l1-l2;
        System.out.println("Occurrence Of A Char In String: " + charcount);
    }
}