import java.util.*;
class Assignment3
{
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		int[] arr = new int[5];
		int sum=0;
		double avg;
		for (int i = 0; i < 5; i++) {
			System.out.println("Please enter a number: ");
			arr[i] = sc.nextInt();
			sum+=arr[i]
		}
		avg=sum/5;
		
		try{
			
      }
      catch(ArrayIndexOutOfBoundsException e){
         System.out.println ("ArrayIndexOutOfBounds");
      }
	  
	}
}