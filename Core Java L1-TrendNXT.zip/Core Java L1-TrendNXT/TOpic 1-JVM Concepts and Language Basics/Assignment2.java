class Assignment2
{
	public static void main (String[] args)
	{
		int a=(-5+8*6);
		int b=((55+9) % 9);
		int c=( 20 + -3*5 / 8);
		int d=(5 + 15 / 3 * 2 - 8 % 3);
		System.out.println("a="+a);
		System.out.println("b="+b);
		System.out.println("c="+c);
		System.out.println("d="+d);
	}
}