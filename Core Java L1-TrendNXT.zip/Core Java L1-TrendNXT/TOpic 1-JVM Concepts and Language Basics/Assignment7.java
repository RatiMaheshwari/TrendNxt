import java.io.*;

public class Assignment7 {
    public static void main(String[] args)throws IOException {
     
      int n=3;
      System.out.println(" The factorial of "+n +"="+ factorial(n));
        
    
}
       public static  int  factorial(int n) {
   if (n == 0)
        return 1;
    else {
        int newVal = n*factorial(n-1);
        return newVal;
    }
}
}