public class Assignment6 {
    public static void main(String[] args)throws IOException {
          int i;
		  int arr[]={3,76,5,87,42,44,99,7,4,98};
         int max = arr[0]; 
        
         for (i = 1; i < arr.length; i++) 
             if (arr[i] > max) 
                 max = arr[i]; 
        
      System.out.println(" The largest number of the array is "+max); 
	  
	  }
	  }