import java.io.*;

public class Assignment5 {
    public static void main(String[] args)throws IOException {
        
        BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
        int num=0;
        System.out.println("Enter the number:");
        num=Integer.parseInt(br.readLine());
        int a=0,sum=0;
        while(num!=0){
            a=num%10;
            sum+=a;
            num=num/10;
        }
        System.out.println("The sum of all the digits entered is: "+sum);
        
    }
}
