import java.util.*;
import java.util.Map.Entry;

public class Assignment4 {

	public static void main(String[] args) {
		Map<String,String> map = new HashMap<String,String>();
		map.put("Chandler","91-9456789876");
		map.put("Joey", "91-8767685432");
		map.put("Rachel", "91-8565432124");
		map.put("Phoebe", "91-7654321230");
		
		Set set = map.entrySet();
		System.out.println("Enter a name: ");
		Scanner sc = new Scanner(System.in);
		String s = sc.next();
		Iterator it = set.iterator();
		while(it.hasNext()) {
			Map.Entry obj = (Entry) it.next();
			if(obj.getKey().equals(s)) {
				System.out.println("The phone number of "+obj.getKey()+" is "+obj.getValue());
			}
		}
	}

}
