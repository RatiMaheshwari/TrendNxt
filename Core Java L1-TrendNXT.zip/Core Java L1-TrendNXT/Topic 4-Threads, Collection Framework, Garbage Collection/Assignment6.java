class A1{
	protected void finalize(){
		System.out.println("Finalize method called");
	}
}

public class Assignment6 {

	public static void main(String[] args) {
		A1 a = new A1();
		a = new A1();
		a = new A1();
		Runtime.getRuntime().gc();

	}

}
