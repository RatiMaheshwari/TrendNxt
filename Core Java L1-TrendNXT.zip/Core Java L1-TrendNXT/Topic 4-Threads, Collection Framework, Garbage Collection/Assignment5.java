import java.util.*;

public class Assignment5 {

	public static void main(String[] args) {
		Set<String> set = new HashSet<String>();
		set.add("Joey");
		set.add("Phoebe");
		set.add("Rachel");
		set.add("Monica");
		set.add("Ross");
		set.add("Chandler");
		Iterator itr = set.iterator();
		while(itr.hasNext()) {
			System.out.println(itr.next());
		}

	}

}
