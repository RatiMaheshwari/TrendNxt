package Assignment5;

class Piano extends Instrument {
	void play() {
		System.out.println("tan tan tan");
	}
}
