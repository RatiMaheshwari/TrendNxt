package Assignment5;

class Flute extends Instrument {
	void play() {
		System.out.println("toot toot toot");
	}
}
