package Assignment5;

abstract class Instrument {
	abstract void play();
}
