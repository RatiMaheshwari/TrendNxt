import java.io.*;
class Book {
String isbn, title;
double price;
Book(String isbn,String title,double price){
	 this.isbn=isbn;
	 this.title=title;
	 this.price=price;
}
void displayDetails(){
	 System.out.println("Book: \nIsbn:"+isbn+"\nTitle:"+title+"\nPrice:"+price);
 }
public static void main(String[] args){
    Novel book=new Novel("5432566","Discovery Of India",250.75,"Pt. Jawaharlal Nehru");
    Magazine book1=new Magazine("5432566","Discovery Of India",250.75,"Reality");
  
      book.displayDetails();
      book1.displayDetails();
  }
 
}
class Novel extends Book{
	String author;
	Novel(String isbn,String title,double price,String author){
		super(isbn, title, price);
		this.author=author;			
	}
	void displayDetails(){
	 System.out.println("Novel: \nIsbn:"+isbn+"\nTitle:"+title+"\nPrice:"+price+"\nAuthor:"+author);
 }
}
class Magazine extends Book{
	String type;
	Magazine(String isbn,String title,double price,String type){
	super(isbn, title, price);
		this.type=type;			
	}
	void displayDetails(){
	 System.out.println("Book: \nIsbn:"+isbn+"\nTitle:"+title+"\nPrice:"+price+"\ntype:"+type);
 }
}