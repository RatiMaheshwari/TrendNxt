public class TestEmail {
	public static void main(String[] args) {
		
		Email e = new Email();
		e.setText("This text contains email details in the document.");
		e.setSender("joey@xyz.com");
		e.setRecepient("chandler@xyz.com");
		e.setTitle("Demo");
		System.out.println(e.toString());
	}
}
