import java.io.*;
class Book {
String isbn, title, author;
double price;
 Book(String isbn,String title,String author,double price){
	 this.isbn=isbn;
	 this.title=title;
	 this.author=author;
	 this.price=price;
 }
 void displayDetails(){
	 System.out.println("Book: \nIsbn:"+isbn+"\nTitle:"+title+"\nAuthor:"+author+"\nPrice:"+price);
 }
 void discountedprice(double d){
     double discount=(d/100.0)*price;
     this.price=price-discount;
 }
  public static void main(String[] args){
      Book book=new Book("5432566","Discovery Of India","Pt. Jawaharlal Nehru",250.75);
      book.discountedprice(10.00);
      book.displayDetails();
  }
}